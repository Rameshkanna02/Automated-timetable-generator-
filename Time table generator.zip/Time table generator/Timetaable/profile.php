<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];

$q1=mysql_query("select * from cw_student where uname='$uname'");	
$r1=mysql_fetch_array($q1);	
$photo=$uname.".jpg";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php include("include/title.php"); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>


<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
</head>

<body>
  
<?php include("link_home.php"); ?>
 <!--start content area-->
<div class="row">
			<div class="col-lg-4">
				<div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>Profile</h4>
                </div>
                <div class="card-block">
                  <p>&nbsp;</p>
                 
				 
				 
                  <table width="100%" border="1">
                    <tr>
                      <td colspan="2" align="center" scope="col"><img src="photo/<?php echo $photo; ?>" width="120" height="150" /></td>
                    </tr>
<tr>
                     <td style="text-align: center;">RegNo: <?php if($r1['regno']) echo $r1['regno']; else echo "-"; ?></td>
                      
                    </tr>
                    <tr>
                      <td style="text-align: center;">Name: <?php echo $r1['name']; ?></td>
                    </tr>
                   
                  </table>
                </div>
              </div>
			  
			  <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>Personal Details</h4>
                </div>
                <div class="card-block">
                  <p>E-mail: <?php echo $r1['email']; ?></p>
				  <p>Mobile No: <?php echo $r1['mobile']; ?></p>
				  <p>Date Of Birth:<?php echo $r1['dob']; ?></p>
                                                                  <p>Religion:<?php echo $r1['religion']; ?></p>
                                                                  <p>Nationality:<?php echo $r1['nationality']; ?></p>
                                                                  <p>Caste:<?php echo $r1['caste']; ?></p>
                                                                  <p>Blood Group:<?php echo $r1['bgroup']; ?></p>
                </div>
              </div>
			  
			</div>
			
			<!--------------------------------------------------------->
	<br>		
            <div class="col-lg-4">
              <div class="card">
                <div class="card-header d-flex align-items-center">
 <h4>Father Details</h4>
                </div>
                <div class="card-block">
                  <p>Name:<?php echo $r1['father']; ?></p>
				  <p>Mobile No: <?php echo $r1['mobile2']; ?></p>
				 <p>Occupation:<?php echo $r1['occupation']; ?></p>
				 <p>Annual Income:<?php echo $r1['income']; ?></p>
				 
                  
                </div>
              </div><br>
<div class="card">
                <div class="card-header d-flex align-items-center">
 <h4>Mother Details</h4>
                </div>
                <div class="card-block">
                  <p>Name:<?php echo $r1['mother']; ?></p>
				  <p>Mobile No: <?php echo $r1['mobile3']; ?></p>
				 <p>Occupation:<?php echo $r1['moccupation']; ?></p>
				 <p>Annual Income:<?php echo $r1['mincome']; ?></p>
				 
                  
                </div>
              </div><br>
	
			  
			  <div class="card">
                <div class="card-header d-flex align-items-center">
                 <h4>Communication Address</h4>
                </div>
                <div class="card-block">
                  <p>Address: <?php echo $r1['address']; ?></p>
				  <p>City: <?php echo $r1['city']; ?></p>
				 <p>E-mail: <?php echo $r1['email']; ?></p>
				 <p>Mobile No.: <?php echo $r1['mobile']; ?></p>
				 <p>Parent No.: <?php echo $r1['mobile2']; ?></p>
                </div>
              </div>
			  
			 </div> 
			<!---------------------------------------------------------> 
			 <div class="col-lg-4">
				 <div class="card">
                <div class="card-header d-flex align-items-center">
                <h4>Course Details</h4>
                </div>
                <div class="card-block">
                 <p>Department: <?php echo $r1['dept']; ?></p>
				  <p>Course: <?php echo $r1['course']; ?></p>
				   <p>Semester:  <?php echo $r1['semester']; ?></p>
				   <p>Batch: <?php echo $r1['year']; ?></p>
                  
                </div>
              </div><br>
<div class="card">
                <div class="card-header d-flex align-items-center">
                <h4>10th Details</h4>
                </div>
                <div class="card-block">
                  <p>School Name: <?php echo $r1['school2']; ?></p>
                  <p>Board: <?php echo $r1['board2']; ?></p>
                                                                  <p>Year Of Passing: <?php echo $r1['yop2']; ?></p>
				  <p>Total Marks: <?php echo $r1['tmark2']; ?></p>
				   <p>Marks Scored:  <?php echo $r1['smark2']; ?></p>
				   <p>Percentage: <?php echo $r1['per2']; ?></p>
                  
                </div>
              </div><br>
<div class="card">
                <div class="card-header d-flex align-items-center">
                <h4>12th Details</h4>
                </div>
                <div class="card-block">
                  <p>School Name: <?php echo $r1['school1']; ?></p>
                  <p>Board: <?php echo $r1['board1']; ?></p>
                                                                  <p>Year Of Passing: <?php echo $r1['yop1']; ?></p>
				  <p>Total Marks: <?php echo $r1['tmark1']; ?></p>
				   <p>Marks Scored:  <?php echo $r1['smark1']; ?></p>
				   <p>Percentage: <?php echo $r1['per1']; ?></p>
                  
                </div>
              </div>

	
			</div>

</div>

  <p>&nbsp;</p>
</body>
</html>