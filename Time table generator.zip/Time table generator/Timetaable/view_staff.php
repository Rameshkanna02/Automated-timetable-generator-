<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];

?>
<!DOCTYPE html>
<html>
<head>
<title><?php include("include/title.php"); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>


<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

</head>
<body>

<?php include("link_admin.php"); ?>


<!--start content area-->
  <?php
if($_REQUEST['act']=="success")
{
?>
<div class="alert alert-success">
  <strong>Register Success!</strong>
</div>
<?php
}
if($_REQUEST['act']=="wrong")
{
?>

<div class="alert alert-warning">
  <strong>Warning!</strong> This Username already exist!
</div>
<?php
}
if($_REQUEST['act']=="1")
{
mysql_query("update cw_staff set status=1 where id=$sid");
?>
<script language="javascript">
window.location.href="view_staff.php?dept=<?php echo $dept; ?>";
</script>
<?php
}
if($_REQUEST['act']=="2")
{
mysql_query("update cw_staff set status=0 where id=$sid");
?>
<script language="javascript">
window.location.href="view_staff.php?dept=<?php echo $dept; ?>";
</script>
<?php
}
?>

	 
	 
	  <div class="col-lg-8">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display display">
                    <h2>Staff</h2>
                  </h2>
                </div>
                <div class="card-block">
                  <p></p>
                  <form name="name" method="post">
				  <div class="form-group">
                      <label>Department</label>
                      <select name="dept" class="form-control" required>
					  <option value="">-Department-</option>
					  <?php
					  $dq=mysql_query("select * from cw_dept");
					  while($dr=mysql_fetch_array($dq))
					  {
					  ?>
					  <option><?php echo $dr['department']; ?></option>
					  <?php
					  }
					  ?>
					  </select>
                    </div>
					
					
                   
                    <div class="form-group">       
                      <input type="submit" name="btn" value="Submit" class="btn btn-primary">
                    </div>
                  </form>
                </div>
              </div>
	 </div>
	  <?php
	
	 if($dept!="")
	 {
	 
	 
	 
	 $qry=mysql_query("select * from cw_staff where dept='$dept'");
	 $num=mysql_num_rows($qry);
	 if($num>0)
	 {
	 ?>
	 
	 <table width="45%" class="table table-bordered">
				<thead>
				  <tr>
					<th>Sno</th>
					<th>Staff ID </th>
					<th>Name</th>
					<th>Gender</th>
					<th>D.O.B</th>
					<th>Mobile</th>
					<th>E-mail</th>
					<th>Designation</th>
					<th>Action</th>
				  </tr>
				</thead>
				<tbody>
				<?php
				$i=0;
				while($row=mysql_fetch_array($qry))
				{
				$i++;
				?>
				  <tr>
					<td><?php echo $i; ?></td>
					<td><?php echo $row['uname']; ?></td>
					<td><?php echo $row['name']; ?></td>
					<td><?php echo $row['gender']; ?></td>
					<td><?php echo $row['dob']; ?></td>
					<td><?php echo $row['mobile']; ?></td>
					<td><?php echo $row['email']; ?></td>
					<td><?php echo $row['designation']; ?></td>
					<td><?php 
					if($row['status']=="1")
					{
					echo '<a href="view_staff.php?act=2&sid='.$row['id'].'">In-Activate</a>'; 
					}
					else
					{
					echo '<a href="view_staff.php?act=1&sid='.$row['id'].'">Activate</a>'; 
					}
					?></td>
				  </tr>
				  <?php

				  }
				  ?>
				</tbody>
	   </table>
	   <?php
	   }
	   }
	   ?>
</body>
</html>
