<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];
$q1=mysql_query("select * from cw_staff where uname='$uname'");
$r1=mysql_fetch_array($q1);
?>
<!DOCTYPE html>
<html>
<head>
<title><?php include("include/title.php"); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>


<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

</head>
<body>

<?php include("link_staff.php"); ?>


<!--start content area-->
  <?php
if($_REQUEST['act']=="success")
{
?>
<div class="alert alert-success">
  <strong>Register Success!</strong>
</div>
<?php
}
if($_REQUEST['act']=="wrong")
{
?>

<div class="alert alert-warning">
  <strong>Warning!</strong> This Username already exist!
</div>
<p>
  <?php
}
if($_REQUEST['act']=="del")
{
mysql_query("delete from cw_subject where id=$did");
?>
  <script language="javascript">
window.location.href="add_subject.php";
</script>
  <?php
}
?>
  
  
</p>
<h3 align="center">Welcome to Staff Profile </h3>
<table width="361" border="1" align="center">
  <tr>
    <td width="172">Staff ID </td>
    <td width="173"><?php echo $r1['uname']; ?></td>
  </tr>
  <tr>
    <td>Name</td>
    <td><?php echo $r1['name']; ?></td>
  </tr>
  <tr>
    <td>Gender</td>
    <td><?php echo $r1['gender']; ?></td>
  </tr>
  <tr>
    <td>Date of Birth </td>
    <td><?php echo $r1['dob']; ?></td>
  </tr>
  <tr>
    <td>Address</td>
    <td><?php echo $r1['address']; ?></td>
  </tr>
  <tr>
    <td>Mobile No. </td>
    <td><?php echo $r1['mobile']; ?></td>
  </tr>
  <tr>
    <td>E-mail</td>
    <td><?php echo $r1['email']; ?></td>
  </tr>
  <tr>
    <td>Department</td>
    <td><?php echo $r1['dept']; ?></td>
  </tr>
  <tr>
    <td>Designation</td>
    <td><?php echo $r1['designation']; ?></td>
  </tr>
  <tr>
    <td>Skills</td>
    <td><?php echo $r1['skills']; ?></td>
  </tr>
  <tr>
    <td>Handling Subjects </td>
    <td><?php
	$q3=mysql_query("select * from cw_handling where uname='$uname'");
	while($r3=mysql_fetch_array($q3))
	{
	$q4=mysql_query("select * from cw_subject where id='".$r3['subject']."'");
	$r4=mysql_fetch_array($q4);
	$subj[]=$r4['subject'];
	}
	$hand=@implode(",",$subj);
	echo $hand;
	 ?></td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp; </p>
</body>
</html>
