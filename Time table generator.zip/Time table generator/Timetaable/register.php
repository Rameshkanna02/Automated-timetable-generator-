<?php
session_start();
include("include/dbconnect.php");
include("email.php");
extract($_REQUEST);
	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php include("include/title.php"); ?></title>
<link rel="shortcut icon" href="img/icon.ico">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>


<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

</head>
<body>
  <?php include("link_admin.php"); ?>
 <div class="panel panel-default">
  <div class="panel-heading" align="center"><span class="t1"></div>
  <div class="panel-body">
   <h3 align="center"></h3>
  </div>
</div>
 <?php
if($_REQUEST['act']=="success")
{
?>
<div class="alert alert-success">
  <strong>Register Success!</strong> 
</div>
<?php
}
if($_REQUEST['act']=="wrong")
{
?>

<div class="alert alert-warning">
  <strong>Warning!</strong> This Username already exist!
</div>
<?php
}
?>			
 <!--start content area-->
<div class="row">
			<div class="col-lg-3">
				
				<!-- A grey horizontal navbar that becomes vertical on small screens -->
			</div>

			
			
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display display">
                    <h2>New Staff</h2>
                  </h2>
                </div>
                <div class="card-block">
                  <p></p>
                  <form name="name" method="post" enctype="multipart/form-data">
                    
					<div class="form-group">
                      <label>Name</label>
                      <input type="text" name="name" placeholder="Name" class="form-control" required>
                    </div>
                    
               <div class="form-group">
                     
               <label>Gender</label>
                      <input type="radio" name="gender" value="Male"> Male
					  <input type="radio" name="gender" value="Female"> Female
                    </div>
					<div class="form-group">
                      <label>Date of Birth</label>
                      <input type="date" name="dob" placeholder="DD-MM-YYYY" class="form-control" required>
                    </div>
                     <div class="form-group">
                      <label>Address</label>
                      <input type="text" name="address" placeholder="Address" class="form-control" required>
                    </div>
					                                                                           
                    <div class="form-group">
                      <label>Mobile No.</label>
                      <input name="mobile" type="text" class="form-control" maxlength="10" placeholder="Mobile No." required>
                    </div>
                                                                                    <div class="form-group">
                      <label>Email</label>
                      <input type="text" name="email" placeholder="Email Address" class="form-control" required>
                    </div>
                    <div class="form-group">
                      <label>Department</label>
                      <select name="dept" class="form-control">
					  <option value="">-Department-</option>
					  <?php
					  $dq=mysql_query("select * from cw_dept");
					  while($dr=mysql_fetch_array($dq))
					  {
					  ?>
					  <option><?php echo $dr['department']; ?></option>
					  <?php
					  }
					  ?>
					  </select>
                    </div>
					       <div class="form-group">
                      <label>Designation</label>
                      <input type="text" name="desig" placeholder="Designation" class="form-control" required>
                    </div>                                                                
					
                        
                    <div class="form-group">       
                      <input type="submit" name="btn" value="Register" class="btn btn-primary">
                    </div>
                  </form>
                </div>
              </div>

</div>
 <?php
 $msg="";
	 	$rdate=date("d-m-Y");
		$yr=date("y");
	 if(isset($btn))
	 {
          
	 $mq=mysql_query("select max(id) from cw_staff");
	 $mr=mysql_fetch_array($mq);
	 $id=$mr['max(id)']+1;
	 $str=str_pad($id,3,"0",STR_PAD_LEFT);
	 $uname="E".$str;
	 $pass="1234";
	$dd=explode("-",$dob);
	$dob1=$dd[2]."-".$dd[1]."-".$dd[0];
	 $ins=mysql_query("insert into cw_staff(id,name,gender,dob,address,mobile,email,dept,designation,uname,pass,status) values($id,'$name','$gender','$dob1','$address','$mobile','$email','$dept','$desig','$uname','$pass','1')");
                 
	 
	  $objEmail	=	new CI_Email();
					$objEmail->from('college@gmail.com', "Staff Info");
					$objEmail->to("$email");
					$objEmail->subject("Staff Information");
					$objEmail->message("Staff:$name, Username:$uname, Password:$pass");
						
							if ($objEmail->send())
							{	
							//echo 'mail sent successfully';
							}
							else
							{
							}
	 	
	 
	 ?>
	 <script language="javascript">
	 window.location.href="register.php?act=success";
	 </script>
	 <?php
	 	
	 }
	 ?>
<!--end content area-->
  <p align="center" class="msg"><?php
  if($msg!="")
  {
  echo $msg;
  }
  ?></p>
  <p>&nbsp;</p>
</body>
</html>