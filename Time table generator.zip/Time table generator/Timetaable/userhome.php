<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];
$month=date("m");
$year=date("Y");
$q1=mysql_query("select * from cw_student where uname='$uname'");	
$r1=mysql_fetch_array($q1);	
$photo=$uname.".jpg";
$dept=$r1['dept'];
$course=$r1['course'];
$semester=$r1['semester'];
$sem=$r1['semester'];
$q33=mysql_query("select * from cw_student where dept='$dept' && semester='$semester' && course='$course' order by id");
while($r33=mysql_fetch_array($q33))
{
$su++;
	if($uname==$r33['uname'])
	{
	$sid=$su;
	}
}

?>
<!DOCTYPE html>
<html>
<head>
<title><?php include("include/title.php"); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>


<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

</head>
<body>

<?php include("link_home.php"); ?>


<!--start content area-->
<div class="row">
			<div class="col-lg-4">
				<div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>Admission No.: <?php echo $r1['id']; ?></h4>
                </div>
                <div class="card-block">
                  <p>&nbsp;</p>
                 
				 
				 
                  <table width="100%" border="1">
                    <tr>
                      <td colspan="2" align="center" scope="col"><img src="photo/<?php echo $photo; ?>" width="120" height="150" /></td>
                    </tr>
                    <tr>
                      <td colspan="2" scope="col"><?php echo $r1['name']; ?><br />
					  <?php echo $r1['dept']."-".$r1['course']; ?>					  </td>
                    </tr>
                    <tr>
                      <td scope="row">RegNo.: <?php if($r1['regno']) echo $r1['regno']; else echo "-"; ?></td>
                      <td>Ref: <?php echo $r1['uname']; ?></td>
                    </tr>
                  </table>
                </div>
              </div>
			  
			  <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>Time Table</h4>
                </div>
                <div class="card-block">
                  <p><?php
				  $day=date("D");
				  	if($day=="Mon")
					{
					echo "Fisrt Day Order";
					}
					else if($day=="Tue")
					{
					echo "Second Day Order";
					}
					else if($day=="Wed")
					{
					echo "Third Day Order";
					}
					else if($day=="Thu")
					{
					echo "Fourth Day Order";
					}
					else if($day=="Fri")
					{
					echo "Fifth Day Order";
					}
					else if($day=="Sat")
					{
					echo "Sixth Day Order";
					}
				  ?></p>
                </div>
              </div>
			  
			</div>
			
			<!--------------------------------------------------------->
			
            <div class="col-lg-4">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>Attendance</h4>
                </div>
                <div class="card-block">
                  <p>
				  <?php
$s=0;
$q6=mysql_query("select * from cw_attendance where semester='$sem' && dept='$dept' && course='$course'");
$n6=mysql_num_rows($q6);
while($r6=mysql_fetch_array($q6))
{
	$det1=$r6['details'];
	$det2=explode("|",$det1);
	$det3=$det2[$sid-1];
	
	$det4=explode("#",$det3);
		if($det4[2]==8)
		{
		$pre=1;
		}
		else if($det4[2]>=4)
		{
		$pre=0.5;
		}
		else
		{
		$pre=0;
		}
	$s=$s+$pre;	
}

$avg=@($s/$n6)*100;
///////////////////////////////////////////////////////////////
$ss=0;
$q66=mysql_query("select * from cw_attendance where month='$month' && year='$year' && semester='$sem' && dept='$dept' && course='$course'");
$n66=mysql_num_rows($q66);
while($r66=mysql_fetch_array($q66))
{
	$det11=$r66['details'];
	$det22=explode("|",$det11);
	$det33=$det22[$sid-1];
	$det44=explode("#",$det33);
		if($det44[2]==8)
		{
		$pre1=1;
		}
		else if($det44[2]>=4)
		{
		$pre1=0.5;
		}
		else
		{
		$pre1=0;
		}
	$ss=$ss+$pre1;	
}

$avg1=@($ss/$n66)*100;
				  ?>
				  <table width="189" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr>
                          <th width="52" scope="row">Month</th>
                          <td width="137">: <?php echo $n66; ?> days </td>
                        </tr>
                        <tr>
                          <th scope="row">Present</th>
                          <td>: <?php echo $ss; ?> days</td>
                        </tr>
                        <tr>
                          <th scope="row">&nbsp;</th>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <th scope="row">Sem</th>
                          <td>: <?php echo $n6; ?> days </td>
                        </tr>
                        <tr>
                          <th scope="row">Present</th>
                          <td>: <?php echo $s; ?> days</td>
                        </tr>
                        <tr>
                          <th scope="row">Average</th>
                          <td>: <?php echo round($avg,2); ?> % </td>
                        </tr>
                      </table>
				  </p>
                 
				 
				 
                </div>
              </div>
			  
			  <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>Exam Results</h4>
                </div>
                <div class="card-block">
                  <p><?php
				  $q3=mysql_query("select * from cw_result where dept='$dept' && course='$course' && semester='$semester'");
				  $n3=mysql_num_rows($q3);
				  if($n3>0)
				  {
				  $r3=mysql_fetch_array($q3);
				  echo "Result: ".'<a href="'.$r3['rlink'].'" target="_blank">'.$r3['rlink'].'</a>';
				  }
				  else
				  {
				  echo "Empty";
				  }
				  ?> </p>
                 
				 
				 
                </div>
              </div>
			  
			 </div> 
			<!---------------------------------------------------------> 
			 <div class="col-lg-4">
				 <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>News / Events</h4>
                </div>
                <div class="card-block">
                  <p><?php
				  $q4=mysql_query("select * from cw_news where dept='$dept' order by id desc");
				  $n4=mysql_num_rows($q4);
				  if($n4>0)
				  {
				  	while($r4=mysql_fetch_array($q4))
					{
				  echo "<h3>".$r4['title']."</h3>";
				  echo $r4['news']."<br>";
				  echo $r4['rdate']."<br><br>";
				  	}
				  }
				  else
				  {
				  echo "Empty";
				  }
				  ?>
                 </p>
				 
				 
                </div>
              </div>
			</div>

</div>

</body>
</html>
