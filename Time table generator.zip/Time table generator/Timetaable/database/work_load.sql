-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 13, 2020 at 07:36 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `work_load`
--

-- --------------------------------------------------------

--
-- Table structure for table `cw_admin`
--

CREATE TABLE `cw_admin` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cw_admin`
--

INSERT INTO `cw_admin` (`username`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `cw_course`
--

CREATE TABLE `cw_course` (
  `id` int(11) NOT NULL,
  `course` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cw_course`
--

INSERT INTO `cw_course` (`id`, `course`) VALUES
(1, 'BE'),
(2, 'MCA');

-- --------------------------------------------------------

--
-- Table structure for table `cw_dept`
--

CREATE TABLE `cw_dept` (
  `id` int(11) NOT NULL,
  `department` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cw_dept`
--

INSERT INTO `cw_dept` (`id`, `department`) VALUES
(1, 'CSE'),
(2, 'EEE'),
(3, 'ECE'),
(4, 'Mech'),
(5, 'Civil'),
(6, 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `cw_handling`
--

CREATE TABLE `cw_handling` (
  `id` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `subject` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cw_handling`
--

INSERT INTO `cw_handling` (`id`, `uname`, `subject`) VALUES
(1, 'E001', 1),
(2, 'E001', 2);

-- --------------------------------------------------------

--
-- Table structure for table `cw_staff`
--

CREATE TABLE `cw_staff` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `address` varchar(30) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `designation` varchar(30) NOT NULL,
  `skills` varchar(100) NOT NULL,
  `handling` varchar(200) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cw_staff`
--

INSERT INTO `cw_staff` (`id`, `name`, `gender`, `dob`, `address`, `mobile`, `email`, `dept`, `designation`, `skills`, `handling`, `uname`, `pass`, `status`) VALUES
(1, 'Sankar', 'Male', '25-08-1990', '22,ss', 9125437893, 'sankar@gmail.com', 'CSE', 'Professor', 'CPP, Java, PHP', '', 'E001', '1234', 1),
(2, 'Raja', 'Male', '09-05-1987', 'Trichy', 8812344567, 'raja@gmail.com', 'CSE', 'Professor', '', '', 'E002', '1234', 1),
(3, 'Saranya', 'Female', '31-10-1993', '22,ss', 9125437893, 'saran@gmail.com', 'CSE', 'Professor', '', '', 'E003', '1234', 1),
(4, 'Arun', 'Male', '13-08-1989', '43,fff', 8812344567, 'arun@gmail.com', 'CSE', 'Professor', '', '', 'E004', '1234', 1),
(5, 'Kumar', 'Male', '07-06-1990', '23,srirangam', 9012377511, 'kumar@gmail.com', 'CSE', 'Professor', '', '', 'E005', '1234', 1),
(6, 'Usha', 'Female', '30-01-1991', 'Chennai', 8812344567, 'usha@gmail.com', 'CSE', 'Professor', '', '', 'E006', '1234', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cw_subject`
--

CREATE TABLE `cw_subject` (
  `id` int(11) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `course` varchar(20) NOT NULL,
  `scode` varchar(20) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `semester` int(11) NOT NULL,
  `torder` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cw_subject`
--

INSERT INTO `cw_subject` (`id`, `dept`, `course`, `scode`, `subject`, `semester`, `torder`) VALUES
(1, 'CSE', 'BE', 'S1', 'CPP', 4, 1),
(2, 'CSE', 'BE', 'S2', 'Hardware', 4, 1),
(3, 'CSE', 'BE', 'S3', 'Multimedia', 4, 1),
(4, 'CSE', 'BE', 'S4', 'Networking', 4, 1),
(5, 'CSE', 'BE', 'S5', 'CPP Lab', 4, 1),
(6, 'CSE', 'BE', 'S6', 'MM Lab', 4, 1),
(7, 'CSE', 'BE', 'a1', 'Java', 6, 2),
(8, 'CSE', 'BE', 'a2', 'Python', 6, 2),
(9, 'CSE', 'BE', 'a3', 'DSP', 6, 2),
(10, 'CSE', 'BE', 'a4', 'Business', 6, 2),
(11, 'CSE', 'BE', 'a5', 'Java Lab', 6, 2),
(12, 'CSE', 'BE', 'a6', 'Python Lab', 6, 2),
(13, 'CSE', 'BE', 'P1', 'SPM', 8, 3),
(14, 'CSE', 'BE', 'P2', 'MCAP', 8, 3),
(15, 'CSE', 'BE', 'P3', 'HCI', 8, 3),
(16, 'CSE', 'BE', 'P4', 'Project Lab', 8, 3);

-- --------------------------------------------------------

--
-- Table structure for table `cw_time_table`
--

CREATE TABLE `cw_time_table` (
  `id` int(11) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `course` varchar(30) NOT NULL,
  `semester` int(11) NOT NULL,
  `p1` int(11) NOT NULL,
  `p2` int(11) NOT NULL,
  `p3` int(11) NOT NULL,
  `p4` int(11) NOT NULL,
  `p5` int(11) NOT NULL,
  `p6` int(11) NOT NULL,
  `p7` int(11) NOT NULL,
  `s1` varchar(10) NOT NULL,
  `s2` varchar(10) NOT NULL,
  `s3` varchar(10) NOT NULL,
  `s4` varchar(10) NOT NULL,
  `s5` varchar(10) NOT NULL,
  `s6` varchar(10) NOT NULL,
  `s7` varchar(10) NOT NULL,
  `torder` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cw_time_table`
--

INSERT INTO `cw_time_table` (`id`, `dept`, `course`, `semester`, `p1`, `p2`, `p3`, `p4`, `p5`, `p6`, `p7`, `s1`, `s2`, `s3`, `s4`, `s5`, `s6`, `s7`, `torder`) VALUES
(1, 'CSE', 'BE', 4, 1, 2, 3, 3, 4, 2, 1, 'E001', 'E002', 'E003', 'E003', 'E004', 'E002', 'E001', 1),
(2, 'CSE', 'BE', 4, 4, 5, 6, 6, 5, 4, 4, 'E004', 'E005', 'E006', 'E006', 'E005', 'E004', 'E004', 1),
(3, 'CSE', 'BE', 4, 2, 3, 1, 1, 3, 1, 2, 'E002', 'E003', 'E001', 'E001', 'E003', 'E001', 'E002', 1),
(4, 'CSE', 'BE', 4, 5, 6, 4, 5, 6, 3, 6, 'E001', 'E002', 'E003', 'E003', 'E004', 'E002', 'E001', 1),
(5, 'CSE', 'BE', 4, 1, 5, 2, 6, 6, 5, 5, 'E001', 'E002', 'E003', 'E003', 'E004', 'E002', 'E001', 1),
(6, 'CSE', 'BE', 4, 4, 4, 3, 3, 1, 2, 2, 'E001', 'E002', 'E003', 'E003', 'E004', 'E002', 'E001', 1),
(7, 'CSE', 'BE', 6, 4, 5, 6, 6, 1, 4, 4, 'E004', 'E005', 'E006', 'E006', 'E001', 'E004', 'E004', 2),
(8, 'CSE', 'BE', 6, 1, 2, 3, 3, 4, 2, 1, 'E001', 'E002', 'E003', 'E003', 'E004', 'E002', 'E001', 2),
(9, 'CSE', 'BE', 6, 5, 6, 4, 5, 6, 3, 6, 'E005', 'E006', 'E004', 'E005', 'E006', 'E003', 'E006', 2),
(10, 'CSE', 'BE', 6, 2, 3, 1, 4, 3, 1, 2, 'E004', 'E005', 'E006', 'E006', 'E001', 'E004', 'E004', 2),
(11, 'CSE', 'BE', 6, 5, 4, 3, 3, 2, 6, 2, 'E004', 'E005', 'E006', 'E006', 'E001', 'E004', 'E004', 2),
(12, 'CSE', 'BE', 6, 1, 1, 5, 5, 2, 6, 5, 'E004', 'E005', 'E006', 'E006', 'E001', 'E004', 'E004', 2),
(13, 'CSE', 'BE', 8, 2, 3, 1, 4, 3, 1, 2, 'E002', 'E003', 'E001', 'E004', 'E003', 'E001', 'E002', 3),
(14, 'CSE', 'BE', 8, 5, 6, 4, 5, 6, 3, 3, 'E005', 'E006', 'E004', 'E005', 'E006', 'E003', 'E003', 3),
(15, 'CSE', 'BE', 8, 1, 2, 3, 3, 4, 2, 1, 'E001', 'E002', 'E003', 'E003', 'E004', 'E002', 'E001', 3),
(16, 'CSE', 'BE', 8, 4, 5, 6, 6, 5, 4, 4, 'E002', 'E003', 'E001', 'E004', 'E003', 'E001', 'E002', 3),
(17, 'CSE', 'BE', 8, 4, 6, 5, 2, 5, 3, 5, 'E002', 'E003', 'E001', 'E004', 'E003', 'E001', 'E002', 3),
(18, 'CSE', 'BE', 8, 6, 2, 1, 2, 6, 1, 1, 'E002', 'E003', 'E001', 'E004', 'E003', 'E001', 'E002', 3);
