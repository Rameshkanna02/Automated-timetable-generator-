<div class="topnav" id="myTopnav">
  <a href="parhome.php" class="active">Home</a>
  <div class="dropdown">
    <button class="dropbtn">My Accounts 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="profile2.php">My Profile</a>
      
    </div>
  </div> 
  <div class="dropdown">
    <button class="dropbtn">Academis 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="view_table2.php">Timetable</a>
      <a href="view_att2.php">Attendance</a>
	  <a href="view_eva2.php">Evaluation</a>
    </div>
  </div> 
  <a href="logout.php">Logout</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onClick="myFunction()">&#9776;</a>
</div>


<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>