<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php include("include/title.php"); ?></title>
<link rel="shortcut icon" href="img/icon.ico">
<style type="text/css">
<!--
.box {
	background-color: #F3F3F3;
	height: 270px;
	width: 270px;
	border: 1px solid #A8A8A8;
	padding:10px;
}
.box1 {
	background-color: #F3F3F3;
	height: 100px;
	width: 270px;
	border: 1px solid #A8A8A8;
	padding:10px;
}
.box2 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #333333;
	padding:10px;
}
.box3 {
padding:10px;
}
.t1 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 24px;
	font-weight: bold;
	color: #0066CC;
	font-variant: small-caps;
	text-transform: none;
}
.msg {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #FF0000;
}
.box4
{
width:250px;
height:35px;
}
-->
</style>
<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
  
 <div class="panel panel-default">
  <div class="panel-heading" align="center"><span class="t1">Student Information Management System</span></div>
  <div class="panel-body">
   <h3 align="center"></h3>
  </div>
</div>
 <!--start content area-->
<div class="row">
			<div class="col-lg-3">
				
				<!-- A grey horizontal navbar that becomes vertical on small screens -->
			</div>
 <?php
if($_REQUEST['act']=="success")
{
?>
<div class="alert alert-success">
  <strong>Register Success!</strong> <a href="login_stu.php">Login</a>
</div>
<?php
}
if($_REQUEST['act']=="wrong")
{
?>

<div class="alert alert-warning">
  <strong>Warning!</strong> This Username already exist!
</div>
<?php
}
?>			
			
			
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display display">
                    <h2>Registration</h2>
                  </h2>
                </div>
                <div class="card-block">
                  <p></p>
                  <form name="name" method="post" enctype="multipart/form-data">
                    
					<div class="form-group">
                      <label>First Name</label>
                      <input type="text" name="firstname" placeholder="First Name" class="form-control">
                    </div>
                    <div class="form-group">
                      <label>Last Name</label>
                      <input type="text" name="lastname" placeholder="Last Name" class="form-control">
                    </div>
               <div class="form-group">
                     
               <label>Gender</label>
                      <input type="radio" name="gender" value="Male"> Male
					  <input type="radio" name="gender" value="Female"> Female
                    </div>
					<div class="form-group">
                      <label>Roll No</label>
                      <input type="text" name="rollno" placeholder="Roll No" class="form-control">
                    </div>
                                                                                               
                                                                                    <div class="form-group">
                      <label>Mobile No.</label>
                      <input type="text" name="mobile" placeholder="Mobile No." class="form-control">
                    </div>
                                                                                    <div class="form-group">
                      <label>Email</label>
                      <input type="text" name="email" placeholder="Email Address" class="form-control">
                    </div>
                                                                                                 <div class="form-group">
                      <label>Date of Birth</label>
                      <input type="text" name="dob" placeholder="DD-MM-YYYY" class="form-control">
                    </div>
                                                                                                   <div class="form-group">
                      <label>Address</label>
                      <input type="text" name="address" placeholder="Address" class="form-control">
                    </div>
					<div class="form-group">
                      <label>City</label>
                      <input type="text" name="city" placeholder="City" class="form-control">
                    </div>
					<div class="form-group">
                      <label>Nationality</label>
                      <input type="text" name="nationality" placeholder="Nationality" class="form-control">
                    </div>
					<div class="form-group">
                      <label>Religion</label>
                      <input type="text" name="religion" placeholder="Religion" class="form-control">
                    </div>
					<div class="form-group">
                      <label>Caste</label>
                      <select name="caste" class="form-control">
					  <option value="">-Caste-</option>
					  <option>OC</option>
                      <option>BC</option>
					  <option>MBC</option>
                      <option>SC</option>
					  </select>
                    </div>

                        
                                                                                                    <div class="form-group">
                      <label>Department</label>
                      <select name="dept" class="form-control">
					  <option value="">-Department-</option>
					  <?php
					  $dq=mysql_query("select * from cw_dept");
					  while($dr=mysql_fetch_array($dq))
					  {
					  ?>
					  <option><?php echo $dr['department']; ?></option>
					  <?php
					  }
					  ?>
					  </select>
                    </div>
					                                                                        <div class="form-group">
                      <label>Course</label>
                      <select name="course" class="form-control">
					  <option value="">-Course-</option>
					  <option>BE</option>
					  <option>ME</option>
					  </select>
                    </div>
					<div class="form-group">
                      <label>Batch</label>
                      <input type="text" name="year" placeholder="Batch Year" class="form-control">
                    </div>
					<div class="form-group">
                      <label>Mode of Admission</label><br>
                      <input type="radio" name="amode" value="Government Quota"> Government Quota<br>
                      <input type="radio" name="amode" value="Government Quota-First Graduate">Government Quota-First Graduate<br>
                      <input type="radio" name="amode" value="Management Quota"> Management Quota
 </div>
					
                      <div class="form-group">
                      <label>Adhar No</label>
                      <input type="text" name="adharno" placeholder="Adhar No" class="form-control" required>
                    </div>
<div class="form-group">
                      <label>Your Photo</label>
                      <input type="file" name="file">
                    </div>

                    
					
					<div class="form-group">
                      <label>Username</label>
                      <input type="text" name="uname" placeholder="Username" class="form-control">
                    </div>
                   <div class="form-group">
                      <label>Password</label>
                      <input type="password" name="pass" placeholder="Password" class="form-control">
                    </div>
					<div class="form-group">
                      <label>Re-type Password</label>
                      <input type="password" name="cpass" placeholder="Re-type Password" class="form-control">
                    </div>
					
					
					  <h2> Father's details</h2>
					<div class="form-group">
                      <label>Name</label>
                      <input type="text" name="father" placeholder="Father Name" class="form-control">
                    </div>
					
					
					<div class="form-group">
                      <label>Mobile No</label>
                      <input type="text" name="mobile2" placeholder="Mobile No" class="form-control">
                    </div>
					
					
					<div class="form-group">
                      <label>Occupation</label>
                      <input type="text" name="occupation" placeholder="Father Occupation" class="form-control">
                    </div>
					<div class="form-group">
                      <label>Annual Income</label>
                      <input type="text" name="income" placeholder="Annual Income" class="form-control">
                    </div>
					
					
					<h2>Mother's Details</h2>

<div class="form-group">
                      <label>Mother Name</label>
                      <input type="text" name="mother" placeholder="Mother Name" class="form-control">
                    </div>
<div class="form-group">
                      <label>Occupation</label>
                      <input type="text" name="moccupation" placeholder="Mother Occupation" class="form-control">
                    </div>
<div class="form-group">
                      <label>Mobile No.</label>
                      <input type="text" name="mobile3" placeholder="Mobile No." class="form-control">
                    </div>
<div class="form-group">
                      <label>Annual Income</label>
                      <input type="text" name="mincome" placeholder="Annual Income" class="form-control">
                    </div>
					
					
					
					
					<h2>Health Details</h2>

<div class="form-group">
                      <label>Height</label>
                      <input type="text" name="height" placeholder="Height" class="form-control">
                    </div>
<div class="form-group">
                      <label>Weight</label>
                      <input type="text" name="weight" placeholder="Weight" class="form-control">
                    </div>
<div class="form-group">
                      <label>Blood Group</label>
                      <input type="text" name="bgroup" placeholder="Blood Group" class="form-control">
                    </div>

<h2>12th Details</h2>

<div class="form-group">
                      <label>School Name</label>
                      <input type="text" name="school1" placeholder="School Name" class="form-control">
                    </div>
<div class="form-group">
                      <label>Board</label>
                      <input type="text" name="board1" placeholder="Board" class="form-control">
                    </div>

<div class="form-group">
                      <label>Year Of Passing</label>
                      <input type="text" name="yop1" placeholder="Year OF Passing" class="form-control">
                    </div>
<div class="form-group">
                      <label>Total Marks</label>
                      <input type="text" name="tmark1" placeholder="Total Marks" class="form-control">
                    </div>
<div class="form-group">
                      <label>Marks Scored</label>
                      <input type="text" name="smark1" placeholder="Marks Scored" class="form-control">
                    </div>
<div class="form-group">
                      <label>Percentage</label>
                      <input type="text" name="per1" placeholder="Percentage" class="form-control">
                    </div>

<h2>10th Details</h2>

<div class="form-group">
                      <label>School Name</label>
                      <input type="text" name="school2" placeholder="School Name" class="form-control">
                    </div>
<div class="form-group">
                      <label>Board</label>
                      <input type="text" name="board2" placeholder="Board" class="form-control">
                    </div>

<div class="form-group">
                      <label>Year Of Passing</label>
                      <input type="text" name="yop2" placeholder="Year OF Passing" class="form-control">
                    </div>
<div class="form-group">
                      <label>Total Marks</label>
                      <input type="text" name="tmark2" placeholder="Total Marks" class="form-control">
                    </div>
<div class="form-group">
                      <label>Marks Scored</label>
                      <input type="text" name="smark2" placeholder="Marks Scored" class="form-control">
                    </div>
<div class="form-group">
                      <label>Percentage</label>
                      <input type="text" name="per2" placeholder="Percentage" class="form-control">
                    </div>
					
					
					
                        
                    <div class="form-group">       
                      <input type="submit" name="btn" value="Register" class="btn btn-primary">
                    </div>
                  </form>
                </div>
              </div>

</div>
 <?php
 $msg="";
	 	$rdate=date("d-m-Y");
		$yr=date("y");
	 if(isset($btn))
	 {
                                                           if (empty($_POST["name"])) {
                                                           $nameError = "Name is required";
                                                           } else {
                                                           $name = test_input($_POST["name"]);
                                                           // check name only contains letters and whitespace
                                                           if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
			 $nameError = "Only letters and white space allowed";
				}
				}

	 		
			 if(trim($uname)=="") { $msg="Enter the Username"; }
			else if(trim($pass)=="") { $msg="Enter the Password"; }
			else if(trim($cpass)=="") { $msg="Enter the Re-type Password"; }
			else
			{
			
	 $mq=mysql_query("select max(id) from cw_student");
	 $mr=mysql_fetch_array($mq);
	 $id=$mr['max(id)']+1;
	 $str=str_pad($id,3,"0",STR_PAD_LEFT);
	 
	 if($_FILES['file']['name']!="")
	 {
	 $photo=$uname.".jpg";
	 move_uploaded_file($_FILES['file']['tmp_name'],"photo/".$photo);
	 }
	
	 $ins=mysql_query("insert into cw_student(id,regno,name,fname,gender,rollno,dob,mobile,mobile2,email,address,city,nationality,religion,caste,father,occupation,income,mother,moccupation,mobile3,mincome,height,weight,bgroup,school1,board1,yop1,tmark1,smark1,per1,school2,board2,yop2,tmark2,smark2,per2,dept,course,year,amode,adharno,uname,pass,rdate) values($id,'','$firstname','$lastname','$gender','$rollno','$dob','$mobile','$mobile2','$email','$address','$city','$nationality','$religion','$caste','$father','$occupation','$income','$mother','$moccupation','$mobile3','$mincome','$height','$weight','$bgroup','$school1','$board1','$yop1','$tmark1','$smark1','$per1','$school2','$board2','$yop2','$tmark2','$smark2','$per2','$dept','$course','$year','$amode','$adharno','$uname','$pass','$rdate')");
	 
                 
	 
	 
	 	
	 
	 ?>
	 <script language="javascript">
	 window.location.href="register.php?act=success";
	 </script>
	 <?php
	 	}
	 }
	 ?>
<!--end content area-->
  <p align="center" class="msg"><?php
  if($msg!="")
  {
  echo $msg;
  }
  ?></p>
  <p>&nbsp;</p>
</body>
</html>