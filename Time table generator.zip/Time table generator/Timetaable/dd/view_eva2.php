<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];
$regno=$_REQUEST['regno'];
$q4=mysql_query("select * from cw_student where uname='$uname'");
$r4=mysql_fetch_array($q4);
$dept=$r4['dept'];
$sem=$r4['semester'];
$regno=$r4['regno'];

?>
<!DOCTYPE html>
<html>
<head>
<title><?php include("include/title.php"); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>


<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

</head>
<body>

<?php include("link_home.php"); ?>


<!--start content area-->
 <?php
if($_REQUEST['act']=="success")
{
?>
<div class="alert alert-success">
  <strong>Added Successfully...</strong>
</div>
<?php
}
if($_REQUEST['act']=="wrong")
{
?>

<div class="alert alert-warning">
  <strong>Warning!</strong> This Username already exist!
</div>
<?php
}
?>

	 
	 
	  <div class="col-lg-8">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display display">
                    <h2>Test Result</h2>
                  </h2>
                </div>
                <div class="card-block">
                 
                  <form name="name" method="post">
                    <div class="form-group">
                      <label>Test Type</label>

                      <select name="exam_type" class="form-control">
					   <option>Test1</option>
		<option>Test2</option>
		 <option>Test3</option>
					  
					  </select>
                    </div>
					
                    <div class="form-group">       
                      <input type="submit" name="btn" value="Submit" class="btn btn-primary">
                    </div>
                  </form>
                </div>
              </div>
	 </div>
	 <?php
  if(isset($btn))
  {
  $q5=mysql_query("select * from cw_test where regno='$regno' && dept='$dept' && semester='$sem' && exam_type='$exam_type'");
  $n5=mysql_num_rows($q5);
	$r5=mysql_fetch_array($q5);
	if($n5>0)
	{
  ?>
  <table width="350" height="95" border="1" align="left" cellpadding="5">
    <tr>
      <th align="center" class="bg-info" scope="row">Subject</th>
      <th align="center" class="bg-info">Mark</th>
      <th align="center" class="bg-info">Result</th>
    </tr>
    <?php
	$i=0;
	$q3=mysql_query("select * from cw_subject where dept='$dept' && semester='$sem'");
	while($r3=mysql_fetch_array($q3))
	{
	$i++;
	$subj=$r5['subject'.$i];
		
	?>
    <tr>
      <th height="30" align="left" class="bg-warning" scope="row"><?php echo $r3['subject']; ?></th>
      <td align="left" class="bg-warning"><?php echo $subj; ?></td>
      <td align="left" class="bg-warning"><?php 
	  if($subj>=50)
	  {
	  echo "P";
	  }
	  else
	  {
	  echo "RA";
	  }
	  ?></td>
    </tr>
    <?php
	
	}
	?>
  </table>
 <p>&nbsp;</p>
 <p>&nbsp;</p>
 <p>&nbsp;</p>
 <p>&nbsp;</p>
  <p>&nbsp;</p>
   <?php
  
$q2=mysql_query("select * from cw_test where exam_type='$exam_type' && dept='$dept' && semester='$sem' order by average desc");   
while($r2=mysql_fetch_array($q2))
{
$reg=$r2['regno'];
$values[$reg]=$r2['average'];
}   
   
   
   
echo "<h2 align='center'>Percentage</h2>";
echo "<br><br>";
# ------- The graph values in the form of associative array
	/*$values=array(
		"101" => 90,
		"102" => 80);*/

 
	$img_width=550;
	$img_height=400; 
	$margins=20;

 
	# ---- Find the size of graph by substracting the size of borders
	$graph_width=$img_width - $margins * 2;
	$graph_height=$img_height - $margins * 2; 
	$img=imagecreate($img_width,$img_height);

 
	$bar_width=20;
	$total_bars=count($values);
	$gap= ($graph_width- $total_bars * $bar_width ) / ($total_bars +1);

 
	# -------  Define Colors ----------------
	$bar_color=imagecolorallocate($img,10,80,15);
	$background_color=imagecolorallocate($img,180,180,180);
	$border_color=imagecolorallocate($img,200,200,200);
	$line_color=imagecolorallocate($img,220,220,220);
 
	# ------ Create the border around the graph ------

	imagefilledrectangle($img,1,1,$img_width-2,$img_height-2,$border_color);
	imagefilledrectangle($img,$margins,$margins,$img_width-1-$margins,$img_height-1-$margins,$background_color);

 
	# ------- Max value is required to adjust the scale	-------
	$max_value=max($values);
	$ratio= $graph_height/$max_value;

 
	# -------- Create scale and draw horizontal lines  --------
	$horizontal_lines=20;
	$horizontal_gap=$graph_height/$horizontal_lines;

	for($i=1;$i<=$horizontal_lines;$i++){
		$y=$img_height - $margins - $horizontal_gap * $i ;
		imageline($img,$margins,$y,$img_width-$margins,$y,$line_color);
		$v=($horizontal_gap * $i /$ratio);
		imagestring($img,2,5,$y-5,$v,$bar_color);

	}
 
 
	# ----------- Draw the bars here ------
	
	for($i=0;$i< $total_bars; $i++){ 
		# ------ Extract key and value pair from the current pointer position
		list($key,$value)=each($values); 
		$x1= $margins + $gap + $i * ($gap+$bar_width) ;
		$x2= $x1 + $bar_width; 
		$y1=$margins +$graph_height- intval($value * $ratio) ;
		$y2=$img_height-$margins;
		imagestring($img,2,$x1+3,$y1-10,$value,$bar_color);
		imagestring($img,3,$x1+3,$img_height-15,$key,$bar_color);		
		imagefilledrectangle($img,$x1,$y1,$x2,$y2,$bar_color);
	}
	//header("Content-type:image/png");
	imagepng($img,"chart/img1.png");

		
echo '<img src="chart/img1.png">';	  
////////////////////////////////////////////////////////////////////////////////
echo "<br>";
foreach($values as $v1=>$k1)
{
echo '<span class="txt5">'.$v1." => ".$k1." %</span><br>";
}
?>
 <?php
  }
	else
	{
	echo "Empty!!!";
	}

  }
  ?>
	  </div>
	 
</body>
</html>
