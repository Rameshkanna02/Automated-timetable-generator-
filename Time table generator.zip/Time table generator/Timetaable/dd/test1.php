<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];

$q1=mysql_query("select * from cw_student where uname='$uname'");	
$r1=mysql_fetch_array($q1);	
$photo=$uname.".jpg";
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>


<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

</head>
<body>

<div class="topnav" id="myTopnav">
  <a href="#home" class="active">Home</a>
  <a href="#news">News</a>
  <a href="#contact">Contact</a>
  <div class="dropdown">
    <button class="dropbtn">Dropdown 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Link 1</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div> 
  <a href="#about">About</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onClick="myFunction()">&#9776;</a>
</div>

<div style="padding-left:16px">
  <h2>Responsive Topnav with Dropdown</h2>
  <p>Resize the browser window to see how it works.</p>
  <p>Hover over the dropdown button to open the dropdown menu.</p>
</div>

<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>


<!--start content area-->
<div class="row">
			<div class="col-lg-4">
				<div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>Admission No.: <?php echo $r1['id']; ?></h4>
                </div>
                <div class="card-block">
                  <p>&nbsp;</p>
                 
				 
				 
                  <table width="100%" border="1">
                    <tr>
                      <td colspan="2" align="center" scope="col"><img src="photo/<?php echo $photo; ?>" width="120" height="150" /></td>
                    </tr>
                    <tr>
                      <td colspan="2" scope="col"><?php echo $r1['name']; ?><br />
					  <?php echo $r1['dept']."-".$r1['course']; ?>					  </td>
                    </tr>
                    <tr>
                      <td scope="row">RegNo.: <?php if($r1['regno']) echo $r1['regno']; else echo "-"; ?></td>
                      <td>Ref: <?php echo $r1['uname']; ?></td>
                    </tr>
                  </table>
                </div>
              </div>
			  
			  <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>Time Table</h4>
                </div>
                <div class="card-block">
                  <p>&nbsp;</p>
                </div>
              </div>
			  
			</div>
			
			<!--------------------------------------------------------->
			
            <div class="col-lg-4">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>Attendance</h4>
                </div>
                <div class="card-block">
                  <p><img src="photo/<?php echo $photo; ?>" width="120" height="150" /></p>
                 
				 
				 
                </div>
              </div>
			  
			  <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>Exam Results</h4>
                </div>
                <div class="card-block">
                  <p><img src="photo/<?php echo $photo; ?>" width="120" height="150" /></p>
                 
				 
				 
                </div>
              </div>
			  
			 </div> 
			<!---------------------------------------------------------> 
			 <div class="col-lg-4">
				 <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>Events</h4>
                </div>
                <div class="card-block">
                  <p><img src="photo/<?php echo $photo; ?>" width="120" height="150" /></p>
                 
				 
				 
                </div>
              </div>
			</div>

</div>

</body>
</html>
