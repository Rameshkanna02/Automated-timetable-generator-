<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];
$regno=$_REQUEST['regno'];
$q4=mysql_query("select * from cw_student where uname='$uname'");
$r4=mysql_fetch_array($q4);
$dept=$r4['dept'];
$sem=$r4['semester'];
$regno=$r4['regno'];

?>
<!DOCTYPE html>
<html>
<head>
<title><?php include("include/title.php"); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>


<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

</head>
<body>

<?php include("link_home.php"); ?>


<!--start content area-->
 <?php
if($_REQUEST['act']=="success")
{
?>
<div class="alert alert-success">
  <strong>Added Successfully...</strong>
</div>
<?php
}
if($_REQUEST['act']=="wrong")
{
?>

<div class="alert alert-warning">
  <strong>Warning!</strong> This Username already exist!
</div>
<?php
}
?>

	 
	 
	  <div class="col-lg-8">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display display">
                    <h2>Test Result</h2>
                  </h2>
                </div>
                <div class="card-block">
                 
                  <form name="name" method="post">
                    <div class="form-group">
                      <label>Test Type</label>
                      <select name="exam_type" class="form-control">
					   <option>Test1</option>
		<option>Test2</option>
		 <option>Test3</option>
					  
					  </select>
                    </div>
					
                    <div class="form-group">       
                      <input type="submit" name="btn" value="Submit" class="btn btn-primary">
                    </div>
                  </form>
                </div>
              </div>
	 </div>
	 <?php
  if(isset($btn))
  {
  $q5=mysql_query("select * from cw_test where regno='$regno' && dept='$dept' && semester='$sem' && exam_type='$exam_type'");
  $n5=mysql_num_rows($q5);
	$r5=mysql_fetch_array($q5);
	if($n5>0)
	{
  ?>
  <table width="350" height="95" border="1" align="left" cellpadding="5">
    <tr>
      <th align="center" class="bg-info" scope="row">Subject</th>
      <th align="center" class="bg-info">Mark</th>
      <th align="center" class="bg-info">Result</th>
    </tr>
    <?php
	$i=0;
	$q3=mysql_query("select * from cw_subject where dept='$dept' && semester='$sem'");
	while($r3=mysql_fetch_array($q3))
	{
	$i++;
	$subj=$r5['subject'.$i];
		
	?>
    <tr>
      <th height="30" align="left" class="bg-warning" scope="row"><?php echo $r3['subject']; ?></th>
      <td align="left" class="bg-warning"><?php echo $subj; ?></td>
      <td align="left" class="bg-warning"><?php 
	  if($subj>=50)
	  {
	  echo "P";
	  }
	  else
	  {
	  echo "RA";
	  }
	  ?></td>
    </tr>
    <?php
	
	}
	?>
  </table>
  <?php
  }
	else
	{
	echo "Empty!!!";
	}

  }
  ?>
	  </div>
	 
</body>
</html>
