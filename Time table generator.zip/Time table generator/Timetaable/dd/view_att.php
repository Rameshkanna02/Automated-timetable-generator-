<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];

$q1=mysql_query("select * from cw_student where uname='$uname'");	
$r1=mysql_fetch_array($q1);	
$photo=$uname.".jpg";
$dept=$r1['dept'];
$course=$r1['course'];
$sem=$r1['semester'];

$q33=mysql_query("select * from cw_student where dept='$dept' && semester='$sem' && course='$course' order by id");
while($r33=mysql_fetch_array($q33))
{
$su++;
	if($uname==$r33['uname'])
	{
	$sid=$su;
	}
}

?>
<!DOCTYPE html>
<html>
<head>
<title><?php include("include/title.php"); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>
<style type="text/css">
.box1
{
background-color:#CCCCCC;
width:50px;
height:50px;
border:#000000 1px solid;
}
.box2
{
background-color:#99CCFF;
width:50px;
height:50px;
border:#000000 1px solid;
}
.box3
{
background-color:#EAEAEA;
width:50px;
height:50px;
border:#000000 1px solid;
}
.box4
{
background-color:#99CC99;
width:50px;
height:50px;
border:#000000 1px solid;
}
.box5
{
background-color:#FF0000;
width:50px;
height:50px;
border:#000000 1px solid;
}
</style>

<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

    <style type="text/css">
<!--
.box6 {background-color:#FFFF33;
width:50px;
height:50px;
border:#000000 1px solid;
}
-->
    </style>
</head>
<body>

<?php include("link_home.php"); ?>


<!--start content area-->
			 <?php
////////////calendar////////////////////////////////
$month=$_REQUEST['month'];
$year=$_REQUEST['year'];
$d=date("j");
$m=date("n");
$mon=date("M");
$y=date("Y");
//$t=date("t");
$l=date("l");

if($month=="") { $month=$m; }
if($year=="") { $year=$y; }
//echo $month." ".$year;
if($m==$month)
{
$mon2=$m;
}
else
{
	if($month>$m)
	{
	$mm1=$month-$m;
	$mon2=$m+$mm1;
	}
	else if($month<$m)
	{
	$mm2=$m-$month;
	$mon2=$m-$mm2;
	}
}
if($y==$year)
{
$yr2=$y;
}
else
{
	if($year>$y)
	{
	$yy1=$year-$y;
	$yr2=$y+$yy1;
	}
	else
	{
	$yy2=$y-$year;
	$yr2=$y-$yy2;
	}
}
	
	$mon3=$mon2-1;
	if($mon3<1)
	{
	$mon3=12;
	}

	$mon4=$mon2+1;
	if($mon4>12)
	{
	$mon4=1;
	}

if($mon3==12)
{
$yr3=$yr2-1;
}
else
{
$yr3=$year;
}

if($mon4==1)
{
$yr4=$yr2+1;
}
else
{
$yr4=$year;
}

$mmm=array(1=>"Jan",2=>"Feb",3=>"Mar",4=>"Apr",5=>"May",6=>"June",7=>"Jul",8=>"Aug",9=>"Sep",10=>"Oct",11=>"Nov",12=>"Dec");
$days=array(1=>"Sunday",2=>"Monday",3=>"Tuesday",4=>"Wednesday",5=>"Thursday",6=>"Friday",7=>"Saturday");
$ds=array("Sunday"=>1,"Monday"=>2,"Tuesday"=>3,"Wednesday"=>4,"Thursday"=>5,"Friday"=>6,"Saturday"=>7);

echo "<table border=1 align=center>";
echo "<tr>";
echo '<td class=box3>&nbsp;</td>';
echo "<td class=box3 colspan=5 align=center>".$mmm[$month]." ".$year."</td>";
echo '<td class=box3>&nbsp;</td>';
echo "</tr>";
echo "<tr>";
echo "<td class=box3>Sun</td>";
echo "<td class=box3>Mon</td>";
echo "<td class=box3>Tue</td>";
echo "<td class=box3>Wed</td>";
echo "<td class=box3>Thu</td>";
echo "<td class=box3>Fri</td>";
echo "<td class=box3>Sat</td>";
echo "</tr>";

$monarr=array(1=>31,2=>28,3=>31,4=>30,5=>31,6=>30,7=>31,8=>30,9=>30,10=>31,11=>30,12=>31);
$t=$monarr[$month];
if($month==2)
{
	if($year%4==0)
	{
	$t=29;
	}
	else
	{
	$t=28;	
	}
}
if($month<10)
{
$month3="0".$month;
}
for($r=1;$r<=$t;$r++)
{
$ent[$r]=0;
}
$q3=mysql_query("select * from cw_attendance where month='$month3' && year='$year' && dept='$dept' && semester='$sem' && course='$course' order by day");
while($r3=mysql_fetch_array($q3))
{
$det=array();
$stdy2=array();
$edy=$r3['day'];
$det=explode("|",$r3['details']);
$stdy=$det[$sid-1];
$stdy2=explode("#",$stdy);
	
$ent[$edy]=$edy;
$ent2[$edy]=$stdy2[2];
}

	for($i=1;$i<=$t;$i++)
	{
		
	$rd=$d-$i;
	
		if($d>$i)
		{
		$mk=mktime(0,0,0,$mon2,date("d")-$rd,$yr2);
		$dn=date("j",$mk);
		$dy=date("l",$mk);
		}
		else
		{
		$sd=$i-$d;
		$mk=mktime(0,0,0,$mon2,date("d")+$sd,$yr2);
		$dn=date("j",$mk);
		$dy=date("l",$mk);
		}
		
		$col=$ds[$dy];
		
		if($dn==$ent[$i])
		{
			if($ent2[$i]=="8") 
			{
			$class="box4"; 
			}
			else if($ent2[$i]>=4) 
			{
			$class="box6"; 
			}
			else
			{
			$class="box5"; 
			}
		} 
		else 
		{ 
		$class="box2"; 
		}
		
				if($col==1)
				{
				echo "<tr>";
				}
			
				if($col>1 && $dn==1)
				{
				$cl=$col-1;
					for($j=1;$j<=$cl;$j++)
					{
					echo "<td class=box1>&nbsp;</td>";				
					}
					
				echo "<td class=$class>".$dn."</td>";
				}
				else
				{
				echo "<td class=$class>".$dn."</td>";
				}
				
			
				if($col==7)
				{
				echo "</tr>";
				}
	}
echo "</table>";


//////////////////////////////////////////////
//////////////////////////////////////////////
$s=0;
$q6=mysql_query("select * from cw_attendance where semester='$sem' && dept='$dept' && course='$course'");
$n6=mysql_num_rows($q6);
while($r6=mysql_fetch_array($q6))
{
	$det1=$r6['details'];
	$det2=explode("|",$det1);
	$det3=$det2[$sid-1];
	
	$det4=explode("#",$det3);
		if($det4[2]==8)
		{
		$pre=1;
		}
		else if($det4[2]>=4)
		{
		$pre=0.5;
		}
		else
		{
		$pre=0;
		}
	$s=$s+$pre;	
}

$avg=@($s/$n6)*100;
///////////////////////////////////////////////////////////////
$ss=0;
$q66=mysql_query("select * from cw_attendance where month='$month3' && year='$year' && semester='$sem' && dept='$dept' && course='$course'");
$n66=mysql_num_rows($q66);
while($r66=mysql_fetch_array($q66))
{
	$det11=$r66['details'];
	$det22=explode("|",$det11);
	$det33=$det22[$sid-1];
	$det44=explode("#",$det33);
		if($det44[2]==8)
		{
		$pre1=1;
		}
		else if($det44[2]>=4)
		{
		$pre1=0.5;
		}
		else
		{
		$pre1=0;
		}
	$ss=$ss+$pre1;	
}

$avg1=@($ss/$n66)*100;
?>
<p>&nbsp;</p>
	  
					  <p>&nbsp;</p>
					  <table width="189" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr>
                          <th width="52" scope="row" class="box4">&nbsp;</th>
                          <td width="137" class="bg-warning">Full Day Present</td>
                        </tr>
                        <tr>
                          <th scope="row" class="box6">&nbsp;</th>
                          <td class="bg-warning">Half Day Present </td>
                        </tr>
                        <tr>
                          <th scope="row" class="box5">&nbsp;</th>
                          <td class="bg-warning">Absent</td>
                        </tr>
                        <tr>
                          <th scope="row">&nbsp; </th>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <th scope="row">Month</th>
                          <td>: <?php echo $n66; ?> days </td>
                        </tr>
                        <tr>
                          <th scope="row">Present</th>
                          <td>: <?php echo $ss; ?> days</td>
                        </tr>
                        <tr>
                          <th scope="row">&nbsp;</th>
                          <td>&nbsp;</td>
                        </tr>
                        <tr>
                          <th scope="row">Sem</th>
                          <td>: <?php echo $n6; ?> days </td>
                        </tr>
                        <tr>
                          <th scope="row">Present</th>
                          <td>: <?php echo $s; ?> days</td>
                        </tr>
                        <tr>
                          <th scope="row">Average</th>
                          <td>: <?php echo round($avg,2); ?> % </td>
                        </tr>
                      </table>
					  <p>&nbsp;</p>
					 
					  <p>&nbsp;</p>
</body>
</html>
