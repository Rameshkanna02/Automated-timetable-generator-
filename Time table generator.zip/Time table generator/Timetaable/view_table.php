<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];


?>
<!DOCTYPE html>
<html>
<head>
<title><?php include("include/title.php"); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">-->
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>


<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

</head>
<body>

<?php include("link_admin.php"); ?>
  <?php
if($_REQUEST['act']=="success")
{
?>
<div class="alert alert-success">
  <strong>Added Success!</strong>
</div>
<?php

}
?>

<!--start content area-->
 <div class="col-lg-6">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display">Time Table</h2>
                </div>
                <div class="card-block">
				<form name="name" method="post">
				<div class="form-group">
                      <label>Department</label>
                      <select name="dept" class="form-control">
					  <option value="">-Department-</option>
					  <?php
					  $dq=mysql_query("select * from cw_dept");
					  while($dr=mysql_fetch_array($dq))
					  {
					  ?>
					  <option <?php if($dept==$dr['department']) echo "selected"; ?>><?php echo $dr['department']; ?></option>
					  <?php
					  }
					  ?>
					  </select>
                  </div>
				  <div class="form-group">
                      <label>Course</label>
                      <select name="course" class="form-control">
					  <option value="">-Course-</option>
					  <?php
					  $dq1=mysql_query("select * from cw_course");
					  while($dr1=mysql_fetch_array($dq1))
					  {
					  ?>
					  <option <?php if($dr1['course']==$course) echo "selected"; ?>><?php echo $dr1['course']; ?></option>
					  <?php
					  }
					  ?>
					  </select>
                  </div>
					<div class="form-group">
                      <label>Semester</label>
                      <select name="sem" class="form-control">
					  <option>-Semester-</option>
					  <option value="1" <?php if($sem=="1") echo "selected"; ?>>Semester1</option>
					  <option value="2" <?php if($sem=="2") echo "selected"; ?>>Semester2</option>
					  <option value="3" <?php if($sem=="3") echo "selected"; ?>>Semester3</option>
					  <option value="4" <?php if($sem=="4") echo "selected"; ?>>Semester4</option>
					  <option value="5" <?php if($sem=="5") echo "selected"; ?>>Semester5</option>
					  <option value="6" <?php if($sem=="6") echo "selected"; ?>>Semester6</option>
					  <option value="7" <?php if($sem=="7") echo "selected"; ?>>Semester7</option>
					  <option value="8" <?php if($sem=="8") echo "selected"; ?>>Semester8</option>
					  </select>
					  
                    </div>
					<div class="form-group">       
                      <input type="submit" name="btn" value="View" class="btn btn-primary">
                    </div>
					
					
				 
				  </form>
					
				  
                </div>
              </div>
            </div>
	 
	 
	 
 <?php
 

			
					if(isset($btn))
					{
					$q4=mysql_query("select * from cw_subject where dept='$dept' && course='$course' && semester='$sem' order by id");
					$r4=mysql_fetch_array($q4);
					$sid=$r4['id'];
  $q3=mysql_query("select * from cw_time_table where dept='$dept' && course='$course' && semester='$sem'");
	$n3=mysql_num_rows($q3);
	if($n3>0)
	{
	
  ?><H1>TIME TABLE VIEW</H1>
                  <table width="79%" class="table table-striped table-sm" border="1" cellpadding="0" cellspacing="0">
                    <thead>
                      <tr style="background:#0066FF; color:#FFFFFF">
                        <th>#</th>
                        <th class="badge-success">Period/Days</th>
                        <th class="badge-success">Period1</th>
                        <th class="badge-success">Period2</th>
                        <th class="badge-success">Period3</th>
                        <th class="badge-success">Period4</th>
                        <th class="badge-success">Period5</th>
                        <th class="badge-success">Period6</th>
                       
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row">&nbsp;</th>
                        <td>&nbsp;</td>
                        <td colspan="4" align="center">Session1</td>
                        <td colspan="3" align="center">Session2</td>
                      </tr>
					  <?php
					  $i=0;
					  while($row=mysql_fetch_array($q3))
					  {
					  $i++;
					  ?>
                      <tr>
                        <th scope="row"><?php echo $i; ?></th>
                        <th scope="row"><?php
						if($i==1) echo "Monday";
						else if($i==2) echo "Tuesday";
						else if($i==3) echo "Wednesday";
						else if($i==4) echo "Thursday";
						else if($i==5) echo "Friday";
						else if($i==6) echo "Saturday";
						
						
						$sid1=$sid+1;
						$sid2=$sid+2;
						$sid3=$sid+3;
						$sid4=$sid+4;
						$sid5=$sid+5;
						$sid6=$sid+6;
						
						
						
						$qry1=mysql_query("select * from cw_subject where id=".$sid."");
						$row1=mysql_fetch_array($qry1);
						$qry2=mysql_query("select * from cw_subject where id=".$sid1."");
						$row2=mysql_fetch_array($qry2);
						$qry3=mysql_query("select * from cw_subject where id=".$sid2."");
						$row3=mysql_fetch_array($qry3);
						$qry4=mysql_query("select * from cw_subject where id=".$sid3."");
						$row4=mysql_fetch_array($qry4);
						$qry5=mysql_query("select * from cw_subject where id=".$sid4."");
						$row5=mysql_fetch_array($qry5);
						$qry6=mysql_query("select * from cw_subject where id=".$sid5."");
						$row6=mysql_fetch_array($qry6);
						$qry7=mysql_query("select * from cw_subject where id=".$sid6."");
						$row7=mysql_fetch_array($qry7);
						
						$aa=array(1=>$row1['scode'],2=>$row2['scode'],3=>$row3['scode'],4=>$row4['scode'],5=>$row5['scode'],6=>$row6['scode']);
						
						$b1=$row['p1'];
						$c1=$aa[$b1];
						
						$b2=$row['p2'];
						$c2=$aa[$b2];
						
						$b3=$row['p3'];
						$c3=$aa[$b3];
						
						$b4=$row['p4'];
						$c4=$aa[$b4];
						
						$b5=$row['p5'];
						$c5=$aa[$b5];
						
						$b6=$row['p6'];
						$c6=$aa[$b6];
						
						$b7=$row['p7'];
						$c7=$aa[$b7];
						?></th>
                        <th scope="row"><?php echo $c1."-".$row['s1']; ?></th>
                        <th scope="row"><?php echo $c2."-".$row['s2']; ?></th>
                        <th scope="row"><?php echo $c3."-".$row['s3']; ?></th>
                        <th scope="row"><?php echo $c4."-".$row['s4']; ?></th>
                        <th scope="row"><?php echo $c5."-".$row['s5']; ?></th>
                        <th scope="row"><?php echo $c6."-".$row['s6']; ?></th>
                       
                      </tr>
					  <?php
					  }
					  ?>
                    </tbody>
                  </table>
				 
				   <?php
				  }?>
				  
				  
				  <?php
				  $q41=mysql_query("select * from cw_subject where dept='$dept' && course='$course' && semester='$sem' order by id");
					$r41=mysql_fetch_array($q41);
					?>
					<h2>VIEW SUBJECT </h2>
				  <table width="79%" class="table table-striped table-sm" border="1" cellpadding="0" cellspacing="0">
				  <tr style="background:#0066FF; color:#FFFFFF">
				  <td>ID</td><td>Department</td><td>Course</td><td>scode</td><td>Subject</td></tr>
				  
				  <?php
				    $i=0;
					  while($row1=mysql_fetch_array($q41))
					  {
					  $i++;
					  ?>
				   <tr>
				   <th scope="row"><?php echo $i; ?></th>
				     <th scope="row"><?php echo $row1['dept']; ?></th>
                        <th scope="row"><?php echo $row1['course']; ?></th>
                            <th scope="row"><?php echo $row1['scode']; ?></th>
							   <th scope="row"><?php echo $row1['subject']; ?></th>
                       
				   </tr>

				    <?php
				  }
				  ?>
				  </table>
				  
				  
				  
				  <?php
				  }
				  ?>
 
 
</body>
</html>
