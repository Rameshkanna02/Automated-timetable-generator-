<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];

?>
<!DOCTYPE html>
<html>
<head>
<title><?php include("include/title.php"); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>


<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

</head>
<body>

<?php include("link_home.php"); ?>


<!--start content area-->
  <?php
if($_REQUEST['act']=="success")
{
?>
<div class="alert alert-success">
  <strong>Successfully changed!</strong>
</div>
<?php
}

if(isset($btn))
{
		if($oldpass=="")
		{
		?>
		<div class="alert alert-warning">
		  <strong></strong> Enter the Current Password
		</div>
		<?php
		}
		else if($newpass=="")
		{
		?>
		<div class="alert alert-warning">
		  <strong></strong> Enter the New Password
		</div>
		<?php
		}
		else if($cpass=="")
		{
		?>
		<div class="alert alert-warning">
		  <strong></strong> Enter the Re-type Password
		</div>
		<?php
		}
		else if($newpass!=$cpass)
		{
		?>
		<div class="alert alert-warning">
		  <strong></strong> Password not match!
		</div>
		<?php
		}
		else
		{
			$q1=mysql_query("select * from cw_student where pass='$oldpass'");
			$n1=mysql_num_rows($q1);
			if($n1==1)
			{
	mysql_query("update cw_student set pass='$newpass' where uname='$uname' && pass='$oldpass'");
	 ?>
	 <script language="javascript">
	 window.location.href="changepass.php?act=success";
	 </script>
	 <?php
	 		}
			else
			{
			?>
	 <script language="javascript">
	 window.location.href="changepass.php?act=wrong";
	 </script>
	 <?php
			}
		}
}


if($_REQUEST['act']=="wrong")
{
?>

<div class="alert alert-warning">
  <strong>Warning!</strong> Current Password wrong!
</div>
<?php
}
?>

	 
	 
	  <div class="col-lg-8">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display display">
                    <h2>Subject</h2>
                  </h2>
                </div>
                <div class="card-block">
                  <p></p>
                  <form name="name" method="post">
				  
					
                    <div class="form-group">
                      <label>Current Password</label>
                      <input type="password" name="oldpass" placeholder="" class="form-control">
                    </div>
					<div class="form-group">
                      <label>New Password</label>
                      <input type="password" name="newpass" placeholder="" class="form-control">
                    </div>
					
					<div class="form-group">
                      <label>Re-type Password</label>
                      <input type="password" name="cpass" placeholder="" class="form-control">
                    </div>
					
                   
                    <div class="form-group">       
                      <input type="submit" name="btn" value="Submit" class="btn btn-primary">
                    </div>
                  </form>
                </div>
              </div>
	 </div>
	 
	 
	
</body>
</html>
