<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];

?>
<!DOCTYPE html>
<html>
<head>
<title><?php include("include/title.php"); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>


<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

</head>
<body>

<?php include("link_admin.php"); ?>


<!--start content area-->
  <?php
if($_REQUEST['act']=="success")
{
?>
<div class="alert alert-success">
  <strong>Register Success!</strong>
</div>
<?php
}
if($_REQUEST['act']=="wrong")
{
?>

<div class="alert alert-warning">
  <strong>Warning!</strong> This Username already exist!
</div>
<?php
}
if($_REQUEST['act']=="del")
{
mysql_query("delete from cw_subject where id=$did");
?>
<script language="javascript">
window.location.href="add_subject.php";
</script>
<?php
}
?>

	 
	 
	  <div class="col-lg-8">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display display">
                    <h2>Subject</h2>
                  </h2>
                </div>
                <div class="card-block">
                  <p></p>
                  <form name="name" method="post">
				  <div class="form-group">
                      <label>Department</label>
                      <select name="dept" class="form-control" required>
					  <option value="">-Department-</option>
					  <?php
					  $dq=mysql_query("select * from cw_dept");
					  while($dr=mysql_fetch_array($dq))
					  {
					  ?>
					  <option><?php echo $dr['department']; ?></option>
					  <?php
					  }
					  ?>
					  </select>
                    </div>
					<div class="form-group">
                      <label>Course</label>
                      <select name="course" class="form-control" required>
					  <option value="">-Course-</option>
					  <?php
					  $dq1=mysql_query("select * from cw_course");
					  while($dr1=mysql_fetch_array($dq1))
					  {
					  ?>
					  <option><?php echo $dr1['course']; ?></option>
					  <?php
					  }
					  ?>
					  </select>
                    </div>
                    <div class="form-group">
                      <label>Subject Code</label>
                      <input type="text" name="scode" placeholder="Subject Code" class="form-control" required>
                    </div>
					<div class="form-group">
                      <label>Subject Name</label>
                      <input type="text" name="subject" placeholder="Subject Name" class="form-control" required>
                    </div>
					
					
					
					
					<div class="form-group">
                      <label>Semester</label>
                      <select name="semester" class="form-control" required>
					  <option>-Semester-</option>
					  <option value="1">Semester1</option>
					  <option value="2">Semester2</option>
					  <option value="3">Semester3</option>
					  <option value="4">Semester4</option>
					  <option value="5">Semester5</option>
					  <option value="6">Semester6</option>
					  <option value="7">Semester7</option>
					  <option value="8">Semester8</option>
					  </select>
                    </div>
                   
                    <div class="form-group">       
                      <input type="submit" name="btn" value="Register" class="btn btn-primary">
                    </div>
                  </form>
                </div>
              </div>
	 </div>
	  <?php
	$rdate=date("d-m-Y");
	 if(isset($btn))
	 {
	 
	 	$q11=mysql_query("select distinct(semester) from cw_subject where dept='$dept' && course='$course'");
		$n11=mysql_num_rows($q11);
		
	 		$q1=mysql_query("select * from cw_subject where dept='$dept' && course='$course' && semester='$semester'");
			$n1=mysql_num_rows($q1);
			if($n1>0)
			{
				$r1=mysql_fetch_array($q1);
				$torder=$r1['torder'];
			}
			else
			{
				$torder=$n11+1;
			}
			
	 $mq=mysql_query("select max(id) from cw_subject");
	 $mr=mysql_fetch_array($mq);
	 $id=$mr['max(id)']+1;
	 $ins=mysql_query("insert into cw_subject(id,dept,course,scode,subject,semester,torder) values($id,'$dept','$course','$scode','$subject','$semester','$torder')");
	 ?>
	 <script language="javascript">
	 window.location.href="add_subject.php?act=success";
	 </script>
	 <?php
	 		
	 }
	 
	 
	 $qry=mysql_query("select * from cw_subject");
	 ?>
	 
	 <table width="45%" class="table table-bordered">
				<thead>
				  <tr>
					<th>Sno</th>
					<th>Dept</th>
					<th>Course</th>
					<th>S.Code</th>
					<th>Subject</th>
					<th>Semester</th>
					<th>Action</th>
				  </tr>
				</thead>
				<tbody>
				<?php
				$i=0;
				while($row=mysql_fetch_array($qry))
				{
				$i++;
				?>
				  <tr>
					<td><?php echo $i; ?></td>
					<td><?php echo $row['dept']; ?></td>
					<th><?php echo $row['course']; ?></th>
					<th><?php echo $row['scode']; ?></th>
					<th><?php echo $row['subject']; ?></th>
					<th><?php echo $row['semester']; ?></th>
					<th><?php echo '<a href="add_subject.php?act=del&did='.$row['id'].'">Delete</a>'; ?></th>
					
				  </tr>
				  <?php

				  }
				  ?>
				</tbody>
	   </table>
</body>
</html>
