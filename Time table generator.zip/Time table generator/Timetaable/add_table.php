<?php
session_start();
include("include/dbconnect.php");
extract($_REQUEST);
$uname=$_SESSION['uname'];






if(isset($btn))
{
$q1=mysql_query("select * from cw_subject where dept='$dept' && course='$course' && semester='$sem'");
$n1=mysql_num_rows($q1);
	if($n1>0)
	{
	$r1=mysql_fetch_array($q1);
	$torder=$r1['torder'];
		if($torder=="1")
		{
		$ar=array(1=>array(1,2,3,3,4,2,1),
			2=>array(4,5,6,6,5,4,4),
			3=>array(2,3,1,1,3,1,2),
			4=>array(5,6,4,5,6,3,6),
			5=>array(1,5,2,6,6,5,5),
			6=>array(4,4,3,3,1,2,2));
		}
		else if($torder=="2")
		{
		$ar=array(1=>array(4,5,6,6,1,4,4,1),
			2=>array(1,2,3,3,4,2,1),
			3=>array(5,6,4,5,6,3,6),
			4=>array(2,3,1,4,3,1,2),
			5=>array(5,4,3,3,2,6,2),
			6=>array(1,1,5,5,2,6,5));
		}
		else if($torder=="3")
		{
		$ar=array(1=>array(2,3,1,4,3,1,2),
			2=>array(5,6,4,5,6,3,3),
			3=>array(1,2,3,3,4,2,1),
			4=>array(4,5,6,6,5,4,4),
			5=>array(4,6,5,2,5,3,5),
			6=>array(6,2,1,2,6,1,1));
		}
		else if($torder=="4")
		{
		$ar=array(1=>array(5,6,4,5,6,3,6),
			2=>array(2,3,1,4,3,1,2),
			3=>array(4,5,6,6,5,4,4),
			4=>array(1,2,3,3,4,2,1),
			5=>array(2,3,1,1,1,2,6),
			6=>array(5,5,2,4,5,3,6));
		}
		
		$q3=mysql_query("select * from cw_staff where dept='$dept' && status=1");
		while($r3=mysql_fetch_array($q3))
		{
		$sr[]=$r3['uname'];
		}
		echo $cnt=count($sr);
		if($cnt>=6)
		{
		$p1=$sr[0];
		$p2=$sr[1];
		$p3=$sr[2];
		$p4=$sr[3];
		$p5=$sr[4];
		$p6=$sr[5];
		}
		else if($cnt==5)
		{
		$p1=$sr[0];
		$p2=$sr[1];
		$p3=$sr[2];
		$p4=$sr[3];
		$p5=$sr[4];
		$p6=$sr[0];
		}
		else if($cnt==4)
		{
		$p1=$sr[0];
		$p2=$sr[1];
		$p3=$sr[2];
		$p4=$sr[3];
		$p5=$sr[0];
		$p6=$sr[1];
		}
		else if($cnt==3)
		{
		$p1=$sr[0];
		$p2=$sr[1];
		$p3=$sr[2];
		$p4=$sr[0];
		$p5=$sr[1];
		$p6=$sr[2];
		}
		else if($cnt==2)
		{
		$p1=$sr[0];
		$p2=$sr[1];
		$p3=$sr[0];
		$p4=$sr[1];
		$p5=$sr[0];
		$p6=$sr[1];
		}
		else if($cnt==1)
		{
		$p1=$sr[0];
		$p2=$sr[0];
		$p3=$sr[0];
		$p4=$sr[0];
		$p5=$sr[0];
		$p6=$sr[0];
		}
		
		$srarr=array(1=>$p1,2=>$p2,3=>$p3,4=>$p4,5=>$p5,6=>$p6);
			foreach($ar[1] as $x1)
			{
				$y1[]=$srarr[$x1];
			}
			
			foreach($ar[2] as $x2)
			{
				$y2[]=$srarr[$x2];
			}
			foreach($ar[3] as $x3)
			{
				$y3[]=$srarr[$x3];
			}
			foreach($ar[1] as $x4)
			{
				$y4[]=$srarr[$x4];
			}
			foreach($ar[1] as $x5)
			{
				$y5[]=$srarr[$x5];
			}
			foreach($ar[1] as $x6)
			{
				$y6[]=$srarr[$x6];
			}
		
		$q2=mysql_query("select * from cw_time_table where dept='$dept' && course='$course' && semester='$sem' order by id");
		$n2=mysql_num_rows($q2);
		if($n2==0)
		{
		$mq=mysql_query("select max(id) from cw_time_table");
	 $mr=mysql_fetch_array($mq);
	 $id=$mr['max(id)']+1;
	 

		$ins=mysql_query("insert into cw_time_table(id,dept,course,semester,p1,p2,p3,p4,p5,p6,p7,s1,s2,s3,s4,s5,s6,s7,torder) values($id,'$dept','$course','$sem','".$ar[1][0]."','".$ar[1][1]."','".$ar[1][2]."','".$ar[1][3]."','".$ar[1][4]."','".$ar[1][5]."','".$ar[1][6]."','".$y1[0]."','".$y1[1]."','".$y1[2]."','".$y1[3]."','".$y1[4]."','".$y1[5]."','".$y1[6]."','".$torder."')");
		
		
		$ins2=mysql_query("insert into cw_time_table(id,dept,course,semester,p1,p2,p3,p4,p5,p6,p7,s1,s2,s3,s4,s5,s6,s7,torder) values($id+1,'$dept','$course','$sem','".$ar[2][0]."','".$ar[2][1]."','".$ar[2][2]."','".$ar[2][3]."','".$ar[2][4]."','".$ar[2][5]."','".$ar[2][6]."','".$y2[0]."','".$y2[1]."','".$y2[2]."','".$y2[3]."','".$y2[4]."','".$y2[5]."','".$y2[6]."','$torder')");
		
		$ins3=mysql_query("insert into cw_time_table(id,dept,course,semester,p1,p2,p3,p4,p5,p6,p7,s1,s2,s3,s4,s5,s6,s7,torder) values($id+2,'$dept','$course','$sem','".$ar[3][0]."','".$ar[3][1]."','".$ar[3][2]."','".$ar[3][3]."','".$ar[3][4]."','".$ar[3][5]."','".$ar[3][6]."','$y3[0]','$y3[1]','$y3[2]','$y3[3]','$y3[4]','$y3[5]','$y3[6]','$torder')");
		
		$ins4=mysql_query("insert into cw_time_table(id,dept,course,semester,p1,p2,p3,p4,p5,p6,p7,s1,s2,s3,s4,s5,s6,s7,torder) values($id+3,'$dept','$course','$sem','".$ar[4][0]."','".$ar[4][1]."','".$ar[4][2]."','".$ar[4][3]."','".$ar[4][4]."','".$ar[4][5]."','".$ar[4][6]."','$y4[0]','$y4[1]','$y4[2]','$y4[3]','$y4[4]','$y4[5]','$y4[6]','$torder')");
		
		$ins5=mysql_query("insert into cw_time_table(id,dept,course,semester,p1,p2,p3,p4,p5,p6,p7,s1,s2,s3,s4,s5,s6,s7,torder) values($id+4,'$dept','$course','$sem','".$ar[5][0]."','".$ar[5][1]."','".$ar[5][2]."','".$ar[5][3]."','".$ar[5][4]."','".$ar[5][5]."','".$ar[5][6]."','$y5[0]','$y5[1]','$y5[2]','$y5[3]','$y5[4]','$y5[5]','$y5[6]','$torder')");
		
		$ins6=mysql_query("insert into cw_time_table(id,dept,course,semester,p1,p2,p3,p4,p5,p6,p7,s1,s2,s3,s4,s5,s6,s7,torder) values($id+5,'$dept','$course','$sem','".$ar[6][0]."','".$ar[6][1]."','".$ar[6][2]."','".$ar[6][3]."','".$ar[6][4]."','".$ar[6][5]."','".$ar[6][6]."','$y6[0]','$y6[1]','$y6[2]','$y6[3]','$y6[4]','$y6[5]','$y6[6]','$torder')");
		
		}
		else
		{
			while($r2=mysql_fetch_array($q2))
			{
			$br[]=$r2['id'];
			}
		
		mysql_query("update cw_time_table set p1='".$ar[1][0]."',p2='".$ar[1][1]."',p3='".$ar[1][2]."',p4='".$ar[1][3]."',p5='".$ar[1][4]."',p6='".$ar[1][5]."',p7='".$ar[1][6]."',s1='$y1[0]',s2='$y1[1]',s3='$y1[2]',s4='$y1[3]',s5='$y1[4]',s6='$y1[5]',s7='$y1[6]' where id=$br[0]");
		
		mysql_query("update cw_time_table set p1='".$ar[2][0]."',p2='".$ar[2][1]."',p3='".$ar[2][2]."',p4='".$ar[2][3]."',p5='".$ar[2][4]."',p6='".$ar[2][5]."',p7='".$ar[2][6]."',s1='$y2[0]',s2='$y2[1]',s3='$y2[2]',s4='$y2[3]',s5='$y2[4]',s6='$y2[5]',s7='$y2[6]' where id=$br[1]");
		
		mysql_query("update cw_time_table set p1='".$ar[3][0]."',p2='".$ar[3][1]."',p3='".$ar[3][2]."',p4='".$ar[3][3]."',p5='".$ar[3][4]."',p6='".$ar[3][5]."',p7='".$ar[3][6]."',s1='$y3[0]',s2='$y3[1]',s3='$y3[2]',s4='$y3[3]',s5='$y3[4]',s6='$y3[5]',s7='$y3[6]' where id=$br[2]");
		
		mysql_query("update cw_time_table set p1='".$ar[4][0]."',p2='".$ar[4][1]."',p3='".$ar[4][2]."',p4='".$ar[4][3]."',p5='".$ar[4][4]."',p6='".$ar[4][5]."',p7='".$ar[4][6]."',s1='$y4[0]',s2='$y4[1]',s3='$y4[2]',s4='$y4[3]',s5='$y4[4]',s6='$y4[5]',s7='$y4[6]' where id=$br[3]");
		
		mysql_query("update cw_time_table set p1='".$ar[5][0]."',p2='".$ar[5][1]."',p3='".$ar[5][2]."',p4='".$ar[5][3]."',p5='".$ar[5][4]."',p6='".$ar[5][5]."',p7='".$ar[5][6]."',s1='$y5[0]',s2='$y5[1]',s3='$y5[2]',s4='$y5[3]',s5='$y5[4]',s6='$y5[5]',s7='$y5[6]' where id=$br[4]");
		
		mysql_query("update cw_time_table set p1='".$ar[6][0]."',p2='".$ar[6][1]."',p3='".$ar[6][2]."',p4='".$ar[6][3]."',p5='".$ar[6][4]."',p6='".$ar[6][5]."',p7='".$ar[6][6]."',s1='$y6[0]',s2='$y6[1]',s3='$y6[2]',s4='$y6[3]',s5='$y6[4]',s6='$y6[5]',s7='$y6[6]' where id=$br[5]");
		
		
		
		
		
		}
		
	
	
	?>
	<script language="javascript">
	alert("Generated Successfully");
	window.location.href="view_table.php?dept=<?php echo $dept; ?>&course=<?php echo $course; ?>&sem=<?php echo $sem; ?>";
	</script>
	<?php
	}
	else
	{
	?>
	<script language="javascript">
	alert("No Subjects Found!");
	</script>
	<?php
	}
}




?>
<!DOCTYPE html>
<html>
<head>
<title><?php include("include/title.php"); ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #4CAF50;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
    float: left;
    overflow: hidden;
}

.dropdown .dropbtn {
    font-size: 17px;    
    border: none;
    outline: none;
    color: white;
    padding: 14px 16px;
    background-color: inherit;
    font-family: inherit;
    margin: 0;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    float: none;
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
    background-color: #ddd;
    color: black;
}

.dropdown:hover .dropdown-content {
    display: block;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>


<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<link rel="shortcut icon" href="favicon.ico">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Simple Line Icons -->
	<link rel="stylesheet" href="css/simple-line-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Style -->
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

</head>
<body>

<?php include("link_admin.php"); ?>
  <?php
if($_REQUEST['act']=="success")
{
?>
<div class="alert alert-success">
  <strong>Added Success!</strong>
</div>
<?php
}
?>

<!--start content area-->
 <div class="col-lg-6">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h2 class="h5 display">Generate Time Table</h2>
                </div>
                <div class="card-block">
				<form name="name" method="post">
				<div class="form-group">
                      <label>Department</label>
                      <select name="dept" class="form-control">
					  <option value="">-Department-</option>
					  <?php
					  $dq=mysql_query("select * from cw_dept");
					  while($dr=mysql_fetch_array($dq))
					  {
					  ?>
					  <option <?php if($dept==$dr['department']) echo "selected"; ?>><?php echo $dr['department']; ?></option>
					  <?php
					  }
					  ?>
					  </select>
                  </div>
				  <div class="form-group">
                      <label>Course</label>
                      <select name="course" class="form-control">
					  <option value="">-Course-</option>
					  <?php
					  $dq1=mysql_query("select * from cw_course");
					  while($dr1=mysql_fetch_array($dq1))
					  {
					  ?>
					  <option><?php echo $dr1['course']; ?></option>
					  <?php
					  }
					  ?>
					  </select>
                    </div>
					<div class="form-group">
                      <label>Semester</label>
                      <select name="sem" class="form-control">
					  <option>-Semester-</option>
					  <option value="1" <?php if($sem=="1") echo "selected"; ?>>Semester1</option>
					  <option value="2" <?php if($sem=="2") echo "selected"; ?>>Semester2</option>
					  <option value="3" <?php if($sem=="3") echo "selected"; ?>>Semester3</option>
					  <option value="4" <?php if($sem=="4") echo "selected"; ?>>Semester4</option>
					  <option value="5" <?php if($sem=="5") echo "selected"; ?>>Semester5</option>
					  <option value="6" <?php if($sem=="6") echo "selected"; ?>>Semester6</option>
					  <option value="7" <?php if($sem=="7") echo "selected"; ?>>Semester7</option>
					  <option value="8" <?php if($sem=="8") echo "selected"; ?>>Semester8</option>
					  </select>
					  
                    </div>
					<div class="form-group">       
                      <input type="submit" name="btn" value="Generate" class="btn btn-primary">
                    </div>
					
					</form>
				  
                </div>
              </div>
            </div>
	 
	 
	 
 
 
 
</body>
</html>
