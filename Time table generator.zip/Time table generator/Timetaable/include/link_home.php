<table width="100%" border="0" cellpadding="0" cellspacing="0">
<tr><td>
<ul id="menu">
	   <li><a href="index.php" onMouseOver="mopen('m1')" onMouseOut="mclosetime()">Home</a>
	  	  <!-- <div id="m1" onMouseOver="mcancelclosetime()" onMouseOut="mclosetime()" title="Home">
			</div>-->
	   </li>
	   <li><a href="register.php" title="About Us">Create Account</a></li>
</ul>   
</td>


</table>
