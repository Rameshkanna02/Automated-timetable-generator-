<?php
$connect=mysql_connect("localhost","root","") or die("Could not connect!");
mysql_select_db("work_load",$connect);
?>