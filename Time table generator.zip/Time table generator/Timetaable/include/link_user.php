<!--<a href="#">Home</a>&nbsp;&nbsp;|&nbsp;&nbsp;
<a href="user_parchase_order.php">Purchase Registration Form</a>&nbsp;&nbsp;|&nbsp;&nbsp;
<a href="user_purch_view.php">View Purchase</a>&nbsp;&nbsp;|&nbsp;&nbsp;
<a href="logout.php">Logout</a>-->