<ul id="menu">
	   <li><a href="admin.php" onMouseOver="mopen('m1')" onMouseOut="mclosetime()">HOME</a>
	  	  <!-- <div id="m1" onMouseOver="mcancelclosetime()" onMouseOut="mclosetime()" title="Home">
			</div>-->
	   </li>
	<li><a href="admin2.php" onMouseOver="mopen('m1')" onMouseOut="mclosetime()">BLOCKED</a>
	  	  <!-- <div id="m1" onMouseOver="mcancelclosetime()" onMouseOut="mclosetime()" title="Home">
			</div>-->
	   </li>
	   <li><a href="logout.php">LOGOUT</a></li>
</ul>   
