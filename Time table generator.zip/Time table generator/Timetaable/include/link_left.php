<table width="164" border="0" cellspacing="0" cellpadding="5">
          <tr>
            <td align="left"><a href="user_page.php">Compose</a></td>
          </tr>
          <tr>
            <td align="left"><a href="inbox.php">Inbox</a></td>
          </tr>
          <tr>
            <td align="left"><a href="sent.php">Sent</a></td>
          </tr>
          <tr>
            <td align="left"><a href="contact.php">Contacts</a></td>
          </tr>
          <tr>
            <td align="left"><a href="spam.php">Spam</a></td>
          </tr>
          <tr>
            <td align="left"><a href="trash.php">Trash</a></td>
          </tr>
		  <tr>
		    <td align="left"><a href="logs.php">Invalid Logs</a></td>
  </tr>
		  <tr>
            <td align="left"><a href="logout.php">Logout</a></td>
          </tr>
        </table>
